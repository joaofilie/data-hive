<?php

// Verifica se os dados do formulário foram enviados
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Conecta ao banco de dados
	$servername = "localhost";
	$username = "root";
	$password = "SENHA MYSQL";
	$dbname = "NOME DO BANCO DE DADOS";
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Verifica se a conexão foi bem-sucedida
    if (!$conn) {
        die("Erro de conexão: " . mysqli_connect_error());
    }

    // Recebe os dados do formulário
    $cpf = $_POST["cpf"];
    $nome = $_POST["nome"];
    $email = $_POST["email"];

    // Verifica se o CPF ou e-mail já existem na tabela
    $sql = "SELECT * FROM registros WHERE cpf='$cpf' OR email='$email'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // CPF ou e-mail já existem na tabela, envio é cancelado
        echo '<center><div style="background-color: red; color: white; padding: 10px;">Erro: CPF ou e-mail já existem no banco de dados.</div></center>';
    } else {
        // Insere os dados na tabela "registros"
        $sql = "INSERT INTO registros (cpf, nome, email) VALUES ('$cpf', '$nome', '$email')";
        if (mysqli_query($conn, $sql)) {
            echo '<center><div id="mensagem-sucesso" style="background-color: green; color: white; padding: 10px;">Cadastro adicionado com sucesso!</div></center>';

        } else {
            echo "Erro ao adicionar registro: " . mysqli_error($conn);
        }
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conn);
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Adicionar registro</title>
	<link rel="icon" type="image/x-icon" href="img/site.ico">
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <form method="post">
    <h1>Adicionar novo registro</h1>
	
	<div>
			<div class="container">
			<div class="logo">
			<img src="img\logo.png" alt="Logo">
			<style>
				.logo img {
				max-width: 65px;
				margin: auto;
				POSITION:ABSOLUTE;
				TOP:40px;LEFT:680px
				}
			</style>
		</div>
		
    <div class="buttons">
        <form method="POST">
            <label for="cpf">CPF:</label>
            <input type="text" name="cpf" id="cpf" minlength="11" maxlength="14" required>

            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" required>

            <label for="email">E-mail:</label>
            <input type="email" name="email" id="email" required>

            <button type="submit" class="button">Adicionar</button>
			<button class="view-records" id="btn-visualizar" onclick="window.location.href='visualizar.php'">Visualizar registros</button>
        </form>
    </div>
	</body>
</html>
