<!DOCTYPE html>
<html>
<head>
    <title>Visualizar registros</title>
	<link rel="shortcut icon" href="img/site.ico" type="image/x-icon"
	<link rel="icon" type="image/x-icon" href="img/site.ico"">
		<style>
  .logo {
    display: flex;
    align-items: center;
  }
  .logo img {
    max-width: 120px;
    width: 20%;
  }
  h1 {
    font-size: 3rem;
    color: #333;
    margin-top: 0;
    margin-bottom: 0;
    margin-left: 10px;
    font-family: courier;
  }
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
  }
</style>

<div class="container">
  <div class="logo">
    <img src="img\server.png" alt="Logo">
    <h1>DATA HIVE</h1>
  </div>
</div>

	
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        th {
            background-color: #333134;
            color: white;
        }
        .btn-voltar {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333134;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 20px;
        }
        .btn-voltar:hover {
            background-color: #8B888D;
        }
        .btn-excluir {
            display: inline-block;
            padding: 5px 10px;
            background-color: red;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .btn-excluir:hover {
            background-color: darkred;
			
		.uscar {
		  text-align: center;
		  background-color: transparent;
		  border: none;
		  color: black;
		  cursor: pointer;
		}
		</style>
</head>
<body>

<style>
	.search-container {
	display: flex;
	align-items: center;
	background-color: #fff;
	border-radius: 20px;
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	margin: 10px 0;
	padding: 0 15px;
	height: 50px;
}

.search-container input[type=text] {
	flex: 1;
	border: none;
	font-size: 16px;
	padding: 0 10px;
	height: 100%;
}

.search-container button[type=submit] {
	background-color: transparent;
	border: none;
	cursor: pointer;
	height: 100%;
	padding: 0 15px;
}

.search-container button[type=submit] i {
	color: #ccc;
	font-size: 20px;
}
</style>

<form method="GET" action="resultado_busca.php">
  <div class="search-container">
    <input type="text" placeholder="Procurar registro..." name="busca">
    <button type="submit">
      <img src="img\pesquisar.png" alt="Buscar" width="20">
    </button>
  </div>
</form>


    <table>
        <thead>
            <tr>
                <th>CPF</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Ações</th>
				<br>
            </tr>
        </thead>
        <tbody>
			<?php
			// Fazer a conexão com o banco de dados
			$servername = "localhost";
			$username = "root";
			$password = "SENHA MYSQL";
			$dbname = "NOME DO BANCO DE DADOS";

			$conn = mysqli_connect($servername, $username, $password, $dbname);
			if (!$conn) {
			  die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
			}

			// Selecionar todos os registros da tabela
			$sql = "SELECT id, cpf, nome, email FROM registros";
			$result = mysqli_query($conn, $sql);

			// Loop através dos registros e exibir na tabela
			if (mysqli_num_rows($result) > 0) {
			  while($row = mysqli_fetch_assoc($result)) {
			    echo "<tr>";
			    echo "<td>" . $row["cpf"] . "</td>";
			    echo "<td>" . $row["nome"] . "</td>";
			    echo "<td>" . $row["email"] . "</td>";
				echo "<td><a href='deletar.php?cpf=" . $row["cpf"] . "' class='btn-excluir'>Excluir</a></td>";
			  echo "</tr>";

			  }
			} else {
			  echo "<tr><td colspan='4'>Nenhum registro encontrado.</td></tr>";
			}
			
			// Fechar a conexão com o banco de dados
			mysqli_close($conn);
			?>
		</tbody>
	</table>

	<center><a href="painel.php" class="btn-voltar">Voltar para cadastrar</a></center>

</body>
</html>