<!DOCTYPE html>
<html>
<head>
	<title>Busca de registros</title>
	<style>
	#btn-visualizar {
	  display: inline-block;
	  padding: 10px 20px;
	  border-radius: 5px;
	  border: 2px solid black;
	  text-align: center;
	  background-color: transparent;
	  color: black;
	  font-size: 16px;
	  font-weight: bold;
	  text-decoration: none;
	  cursor: pointer;
	  transition: background-color 0.2s ease;
	}

	#btn-visualizar:hover {
	  background-color: black;
	  color: white;
	}

		</style>

	<style type="text/css">
		body {
			font-family: Arial, sans-serif;
			background-color: #f2f2f2;
			margin: 0;
			padding: 0;
		}

		h1 {
			font-size: 28px;
			font-weight: bold;
			color: #333;
			margin-top: 30px;
			margin-bottom: 20px;
		}

		hr {
			border: 0;
			height: 1px;
			background-color: #ccc;
			margin-top: 20px;
			margin-bottom: 20px;
		}

		label {
			font-size: 18px;
			font-weight: bold;
			color: #333;
			display: block;
			margin-bottom: 10px;
		}

		input[type="text"] {
			font-size: 16px;
			padding: 10px;
			border-radius: 5px;
			border: 1px solid #ccc;
			width: 300px;
			max-width: 100%;
			margin-bottom: 20px;
			box-sizing: border-box;
		}

		button[type="submit"] {
			font-size: 16px;
			padding: 10px 20px;
			background-color: #333;
			color: #fff;
			border-radius: 5px;
			border: none;
			cursor: pointer;
		}

		button[type="submit"]:hover {
			background-color: #444;
		}

		.container {
			max-width: 800px;
			margin: 0 auto;
			padding: 20px;
			background-color: #fff;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
			border-radius: 5px;
			margin-top: 50px;
		}

		.error {
			font-size: 18px;
			font-weight: bold;
			color: #f00;
			margin-top: 30px;
		}
	</style>
</head>
<body>
	<div class="container">
		<center><h1>Busca de registro</h1></center>
		
		<?php
	// Conecta ao banco de dados
	$servername = "localhost";
	$username = "root";
	$password = "SENHA MYSQL";
	$dbname = "NOME DO BANCO DE DADOS";
	$conn = mysqli_connect($servername, $username, $password, $dbname);

	// Verifica se a conexão foi bem-sucedida
	if (!$conn) {
		die("Erro de conexão: " . mysqli_connect_error());
	}

	// Recebe a busca do formulário e remove os espaços
	$busca = str_replace(' ', '', $_GET["busca"]);

	// Remove os pontos e traços do CPF na busca
	$busca = preg_replace('/[^0-9]/', '', $busca);

	// Realiza a busca no banco de dados
	$sql = "SELECT * FROM registros WHERE REPLACE(REPLACE(cpf, '.', ''), '-', '') LIKE '%$busca%' OR nome LIKE '%$busca%' OR email LIKE '%$busca%'";
	$result = mysqli_query($conn, $sql);

	// Verifica se a consulta foi bem-sucedida
	if (!$result) {
		die('Erro na consulta: ' . mysqli_error($conn));
	}

	// Recebe o ID do registro a ser atualizado
	$id_registro = isset($_GET['id']) ? $_GET['id'] : null;
		
	// Verifica se foram encontrados registros
	if (mysqli_num_rows($result) > 0) {
		
		// Exibe os registros encontrados
		echo "<h1>Resultados da busca</h1>";
		while($row = mysqli_fetch_assoc($result)) {
			echo "<form method='POST' action='editar.php'>";
			echo "CPF: " . $row["cpf"] . "<br>";
			echo "Nome: " . $row["nome"] . "<br>";
			echo "E-mail: " . $row["email"] . "<br>";
			echo "<td><a href='deletarbusca.php?cpf=" . $row["cpf"] . "' class='btn-excluir'>Excluir</a></td>";
			echo "<input type='hidden' name='id' value='" . $row["id"] . "'>";
			echo "</form>";
			echo "<hr>";
		}
	} else {
		// Caso não tenha encontrado nenhum registro
		header("Location: error.html");
		exit();
	}

	// Fecha a conexão com o banco de dados
	mysqli_close($conn);
?>

