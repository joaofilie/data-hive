<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$opcao = $_POST["opcao"];
	if ($opcao == "conversa") {
		// Redirecionar para a página de conversa administrativa
		header("Location: error2.html");
		exit();
	} elseif ($opcao == "novo_registro") {
		// Redirecionar para a página de adicionar um novo registro
		header("Location: painel.php");
		exit();
	} elseif ($opcao == "gerenciar_registro") {
		// Redirecionar para a página de gerenciar ou buscar registro
		header("Location: visualizar.php");
		exit();
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Menu de Seleção</title>
</head>
<body>

			<style>
	body {
	  font-family: Arial, sans-serif;
	  background-color: #f2f2f2;
	}

	h1 {
	  text-align: center;
	  margin-top: 50px;
	  color: #333;
	}

	form {
	  width: 50%;
	  margin: 0 auto;
	  background-color: #fff;
	  padding: 20px;
	  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
	}

	label {
	  display: block;
	  margin-bottom: 10px;
	  color: #666;
	}

	select {
	  display: block;
	  width: 100%;
	  padding: 10px;
	  border: none;
	  border-bottom: 2px solid #ccc;
	  margin-bottom: 20px;
	}

	button[type="submit"] {
	  background-color: #333333;
	  color: #fff;
	  border: none;
	  padding: 10px 20px;
	  font-size: 16px;
	  cursor: pointer;
	  border-radius: 4px;
	  margin-top: 20px;
	}

	button[type="submit"]:hover {
	  background-color: #333131;
	}
			</style>

	<h1>Menu de Seleção</h1>
	<center><p>Por favor, selecione uma das opções abaixo:</p></center>
	<form method="post">
		<label for="opcao">Opção:</label>
		<select name="opcao" id="opcao">
			<option value="conversa">Abrir conversa administrativa</option>
			<option value="novo_registro">Adicionar um novo registro</option>
			<option value="gerenciar_registro">Gerenciar ou buscar registro</option>
		</select>
		<button type="submit">Continuar</button>
	</form>
</body>
</html>
