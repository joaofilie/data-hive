<?php
// Verifica se o método de requisição foi GET e se o CPF do registro foi fornecido
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["cpf"])) {

    // Recebe o CPF do registro a ser deletado
    $cpf = $_GET["cpf"];

    // Conexão com o banco de dados
	$servername = "localhost";
	$username = "root";
	$password = "SENHA MYSQL";
	$dbname = "NOME DO BANCO DE DADOS";

    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
    }

    // Deleta o registro com o CPF fornecido
    $sql = "DELETE FROM registros WHERE cpf = '$cpf'";
    if (mysqli_query($conn, $sql)) {
        echo "Registro deletado com sucesso.";
    } else {
        echo "Erro ao deletar o registro: " . mysqli_error($conn);
    }

    // Fecha a conexão com o banco de dados
    mysqli_close($conn);

    // Redireciona de volta para a página de visualização de registros
    header("Location: resultado_busca.php");

} else {
    // Se o método de requisição não for GET ou se o CPF não for fornecido, redireciona para a página de visualização de registros
    header("Location: resultado_busca.php");
}
