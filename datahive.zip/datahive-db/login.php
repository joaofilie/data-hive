<?php
$admin_username = 'admin';
$admin_password = 'senha123';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Verifique se o nome de usuário e senha são válidos
  if ($username == "admin" && $password == "senha123") {
    // Autenticação bem-sucedida, redirecione para a página de administração
    header('Location: home.php');
    exit;
  } else {
    // Autenticação falhou, exiba uma mensagem de erro
    $error_message = "Usuário ou senha inválidos";
  }
}

// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "SENHA MYSQL";
$dbname = "NOME DO BANCO DE DADOS";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Verificação de erros na conexão
if (!$conn) {
    die("Conexão falhou: " . mysqli_connect_error());
}

// Verificação do envio do formulário
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recuperação dos dados do formulário
    $cpf = $_POST['cpf'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];

    // Inserção dos dados no banco de dados
    $sql = "INSERT INTO registros (cpf, nome, email) VALUES ('$cpf', '$nome', '$email')";
    
    if (mysqli_query($conn, $sql)) {
        echo "Registro inserido com sucesso!";
    } else {
        echo "Erro ao inserir registro: " . mysqli_error($conn);
    }
}

// Fechamento da conexão com o banco de dados
mysqli_close($conn);

?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link rel="icon" type="image/x-icon" href="img/site.ico">
  <style>
    body {
      background-color: #f7f7f7;
      font-family: Arial, sans-serif;
    }

    .container {
      margin: 0 auto;
      max-width: 400px;
      padding: 20px;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 5px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }

    .logo {
      margin: 0 auto;
      text-align: center;
    }

    .logo img {
      max-width: 100%;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 5px;
      font-size: 14px;
      font-weight: bold;
    }

    .form-group input {
      display: block;
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    .form-group button {
      display: block;
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border: none;
      border-radius: 5px;
      background-color: #2980b9;
      color: #fff;
      cursor: pointer;
    }

    .form-group button:hover {
      background-color: #3498db;
    }

    .error-box {
      margin-top: 10px;
      background-color: #F8D7DA;
      color: #721C24;
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 14px;
    }

    .logo img {
      max-width: 150px;
    }
  </style>
</head>
<body>
 <div class="container">
  <div class="logo">
    <img src="img\logo.png" alt="Logo">
  </div>
  <form method="post">
    <div class="form-group">
      <label for="username">Usuário:</label>
      <input type="text" name="username" id="username">
    </div>
    <div class="form-group">
      <label for="password">Senha:</label>
      <input type="password" name="password" id="password">
    </div>
    <div class="form-group">
      <button type="submit">Entrar</button>
      <?php if (isset($error_message)): ?>
        <div class="error-box"><?php echo $error_message; ?></div>
      <?php endif; ?>
    </div>
  </form>
</div>
</body>
</html>