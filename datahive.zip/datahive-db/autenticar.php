<?php
session_start();

$nome = $_POST['nome'];
$senha = $_POST['senha'];

if ($nome == "admin" && $senha == "senha123") {
  $_SESSION['autenticado'] = true;
  header('Location: painel.php');
  exit;
} else {
  $_SESSION['autenticado'] = false;
  header('Location: login.php');
  exit;
}
?>
